# Gaming Platform

A Multi-Level Virtual Points Gaming Platform — a hierarchical, role-based web application for controlled account provisioning, virtual point distribution, and gated access to simple arcade games. Built as an academic project to demonstrate layered backend architecture, role-based access control, and full transaction traceability.

## Project Description

The platform models a four-tier management hierarchy (Super Admin → Level 1 → Level 2 → Level 3 → Player). Accounts are never self-registered; each tier creates and manages the tier directly beneath it. Virtual points — used only to access simple arcade games within the platform, with no real-world monetary value — flow downward through the hierarchy. Every account action, point transfer, and game session is logged for full auditability.

## Objectives

- Demonstrate a secure, role-based, hierarchical account management system
- Implement controlled (non-public) account provisioning
- Implement a virtual points wallet and downward-only transfer system
- Gate access to arcade games behind wallet balance checks
- Provide administrative reporting and a full audit trail
- Apply a clean layered backend architecture (Controller → Service → Repository)

## Tech Stack

**Frontend:** React (Vite), Tailwind CSS, React Router, Axios, TanStack Query, React Hook Form, Zod
**Backend:** Node.js, Express.js
**Database:** PostgreSQL, `pg` (node-postgres), raw SQL, SQL migrations, SQL seeds
**Authentication:** JWT, bcrypt
**Validation:** express-validator
**Security:** Helmet, CORS, Morgan

## Folder Structure

```
gaming-platform/
  client/                 React frontend
  server/
    config/                Environment & app configuration
    controllers/            HTTP request/response handling only
    middleware/              Auth, authorization, logging, error handling
    repositories/            All SQL lives here
    routes/                  Express route definitions
    database/
      connection.js           DB connection pool
      schema.sql               Reference schema
      migrations/               Versioned migration files
      seeds/                     Seed data scripts
    services/                Business logic
    validators/               Request validation schemas
    utils/                    Shared helper functions
    server.js                 App entry point
  docs/                    Full documentation set (see below)
  README.md
  CLAUDE.md
```

## Setup Overview

See [`docs/08_SETUP.md`](docs/08_SETUP.md) for full setup instructions, including Node version, environment variables, database provisioning, migrations, and seed data.

## Development Workflow

See [`docs/02_ARCHITECTURE.md`](docs/02_ARCHITECTURE.md) for the layered architecture and [`CLAUDE.md`](CLAUDE.md) for coding standards and development rules. Git branching and commit conventions are documented at the bottom of `CLAUDE.md`.

## Documentation Index

| Document | Purpose |
|---|---|
| [CLAUDE.md](CLAUDE.md) | Primary reference for all future development sessions |
| [docs/00_PROJECT_OVERVIEW.md](docs/00_PROJECT_OVERVIEW.md) | Business overview, scope, goals |
| [docs/01_REQUIREMENTS.md](docs/01_REQUIREMENTS.md) | Functional & non-functional requirements |
| [docs/02_ARCHITECTURE.md](docs/02_ARCHITECTURE.md) | System architecture |
| [docs/03_DATABASE.md](docs/03_DATABASE.md) | Database design documentation |
| [docs/04_API_SPEC.md](docs/04_API_SPEC.md) | REST API specification |
| [docs/05_BUSINESS_RULES.md](docs/05_BUSINESS_RULES.md) | All business rules |
| [docs/06_PROJECT_STATUS.md](docs/06_PROJECT_STATUS.md) | Current status & roadmap |
| [docs/07_DECISIONS.md](docs/07_DECISIONS.md) | Architectural decision log |
| [docs/08_SETUP.md](docs/08_SETUP.md) | Local development setup |
| [docs/09_DEPLOYMENT.md](docs/09_DEPLOYMENT.md) | Deployment process |

## Future Roadmap

See [`docs/06_PROJECT_STATUS.md`](docs/06_PROJECT_STATUS.md) for phased milestones, and [`docs/01_REQUIREMENTS.md`](docs/01_REQUIREMENTS.md) for the future enhancements backlog.

## Scope Note

This is an academic project. The "virtual points" have no real-world monetary value, are not purchasable or redeemable for cash, and exist solely to gate access to simple, self-contained arcade games within the platform. There is no real-money wagering, betting, or gambling functionality anywhere in this system.